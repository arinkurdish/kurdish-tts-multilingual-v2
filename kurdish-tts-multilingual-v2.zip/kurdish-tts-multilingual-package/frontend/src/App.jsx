import { useState, useEffect } from 'react'
import { Textarea } from '@/components/ui/textarea'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Volume2, Download, Globe, Clock, MapPin } from 'lucide-react'
import NewsTimeline from './components/NewsTimeline'
import LanguageSelector from './components/LanguageSelector'
import { translations, getTranslation, getLanguageDirection, getLanguageName } from './utils/translations'
import './App.css'

function App() {
  const [text, setText] = useState('')
  const [selectedVoice, setSelectedVoice] = useState('news')
  const [selectedLanguage, setSelectedLanguage] = useState('ku-sorani')
  const [isLoading, setIsLoading] = useState(false)
  const [audioUrl, setAudioUrl] = useState(null)
  const [message, setMessage] = useState('')
  const [messageType, setMessageType] = useState('')

  const direction = getLanguageDirection(selectedLanguage)
  const t = (key) => getTranslation(selectedLanguage, key)

  // Update document direction when language changes
  useEffect(() => {
    document.documentElement.dir = direction
    document.documentElement.lang = selectedLanguage
  }, [selectedLanguage, direction])

  const handleConvert = async () => {
    if (!text.trim()) {
      setMessage(t('error'))
      setMessageType('error')
      return
    }

    setIsLoading(true)
    setMessage(t('processing'))
    setMessageType('info')

    try {
      const response = await fetch('/api/tts/convert', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: text,
          voice: selectedVoice,
          language: selectedLanguage
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setAudioUrl(data.audio_url)
        setMessage(t('success'))
        setMessageType('success')
      } else {
        throw new Error('Failed to convert text to speech')
      }
    } catch (error) {
      console.error('Error:', error)
      setMessage(t('error'))
      setMessageType('error')
    } finally {
      setIsLoading(false)
    }
  }

  const handleDownload = async (format) => {
    if (!audioUrl) return

    try {
      const response = await fetch(`/api/tts/download?url=${encodeURIComponent(audioUrl)}&format=${format}`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.style.display = 'none'
        a.href = url
        a.download = `kurdish-tts.${format}`
        document.body.appendChild(a)
        a.click()
        window.URL.revokeObjectURL(url)
        document.body.removeChild(a)
      }
    } catch (error) {
      console.error('Download error:', error)
    }
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-blue-50 to-green-50 ${direction === 'rtl' ? 'font-kurdish' : 'font-latin'}`}>
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <img 
                src="/logo.png" 
                alt="Logo" 
                className="h-12 w-12 rounded-lg shadow-md"
                onError={(e) => {
                  e.target.style.display = 'none'
                }}
              />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {t('title')}
                </h1>
                <p className="text-sm text-gray-600">
                  {t('subtitle')}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <img 
                src="/kurdistan-flag.png" 
                alt="Kurdistan Flag" 
                className="h-8 w-12 rounded shadow-sm"
                onError={(e) => {
                  e.target.style.display = 'none'
                }}
              />
              <LanguageSelector 
                selectedLanguage={selectedLanguage}
                onLanguageChange={setSelectedLanguage}
              />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main TTS Section */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Volume2 className="h-5 w-5 text-blue-600" />
                  {t('title')}
                </CardTitle>
                <CardDescription>
                  {t('subtitle')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Text Input */}
                <div className="space-y-2">
                  <Label htmlFor="text-input">{t('textLabel')}</Label>
                  <Textarea
                    id="text-input"
                    placeholder={t('textPlaceholder')}
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    className="min-h-[120px] resize-none"
                    maxLength={1000}
                    dir={direction}
                  />
                  <div className="text-sm text-gray-500 text-right rtl:text-left">
                    {text.length}/1000
                  </div>
                </div>

                {/* Voice Selection */}
                <div className="space-y-2">
                  <Label htmlFor="voice-select">{t('voiceLabel')}</Label>
                  <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                    <SelectTrigger id="voice-select">
                      <SelectValue placeholder={t('voicePlaceholder')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="news">{t('voices.news')}</SelectItem>
                      <SelectItem value="storyteller">{t('voices.storyteller')}</SelectItem>
                      <SelectItem value="singer">{t('voices.singer')}</SelectItem>
                      <SelectItem value="male">{t('voices.male')}</SelectItem>
                      <SelectItem value="female">{t('voices.female')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Convert Button */}
                <Button 
                  onClick={handleConvert} 
                  disabled={isLoading || !text.trim()}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                >
                  <Volume2 className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                  {isLoading ? t('processing') : t('convertButton')}
                </Button>

                {/* Status Message */}
                {message && (
                  <div className={`p-3 rounded-md text-sm ${
                    messageType === 'success' ? 'bg-green-50 text-green-700 border border-green-200' :
                    messageType === 'error' ? 'bg-red-50 text-red-700 border border-red-200' :
                    'bg-blue-50 text-blue-700 border border-blue-200'
                  }`}>
                    {message}
                  </div>
                )}

                {/* Audio Player */}
                {audioUrl && (
                  <Card className="bg-green-50 border-green-200">
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 text-green-700">
                          <Volume2 className="h-4 w-4" />
                          <span className="font-medium">{t('audioGenerated')}</span>
                        </div>
                        
                        <audio 
                          controls 
                          className="w-full"
                          src={audioUrl}
                        >
                          Your browser does not support the audio element.
                        </audio>

                        {/* Download Options */}
                        <div className="space-y-2">
                          <Label className="text-sm font-medium text-gray-700">
                            {t('downloadAudio')}
                          </Label>
                          <div className="flex flex-wrap gap-2">
                            {['mp3', 'wav', 'ogg', 'm4a', 'flac'].map((format) => (
                              <Button
                                key={format}
                                variant="outline"
                                size="sm"
                                onClick={() => handleDownload(format)}
                                className="text-xs"
                              >
                                <Download className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0" />
                                {t(`downloadFormats.${format}`)}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </div>

          {/* News Timeline */}
          <div className="lg:col-span-1">
            <NewsTimeline language={selectedLanguage} />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center space-y-2">
            <p className="text-sm text-gray-600">
              {t('poweredBy')} 
              <Badge variant="secondary" className="ml-1 rtl:mr-1 rtl:ml-0">
                AI
              </Badge>
            </p>
            <p className="text-xs text-gray-500">
              {t('madeWith')} ❤️ {t('language')}: {getLanguageName(selectedLanguage)}
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

