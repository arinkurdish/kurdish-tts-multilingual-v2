import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, FileAudio, X, CheckCircle, AlertCircle } from 'lucide-react';
import { getTranslation, getLanguageDirection } from '../utils/translations';

const VoiceUpload = ({ language = 'ku-sorani', onClose }) => {
  const [files, setFiles] = useState([]);
  const [voiceConfig, setVoiceConfig] = useState({
    name: '',
    description: '',
    type: 'news',
    language: language
  });
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);

  const direction = getLanguageDirection(language);
  const t = (key) => getTranslation(language, key);

  const voiceTypes = {
    'ku-sorani': [
      { id: 'news', name: 'دەنگی هەواڵ' },
      { id: 'storyteller', name: 'دەنگی چیرۆکبێژ' },
      { id: 'singer', name: 'دەنگی گۆرانیبێژ' },
      { id: 'educational', name: 'دەنگی پەروەردەیی' },
      { id: 'conversational', name: 'دەنگی گفتوگۆ' },
      { id: 'traditional', name: 'دەنگی نەریتی' }
    ],
    'ku-kurmanji': [
      { id: 'news', name: 'Dengê Nûçeyan' },
      { id: 'storyteller', name: 'Dengê Çîrokbêj' },
      { id: 'singer', name: 'Dengê Stran' },
      { id: 'educational', name: 'Dengê Perwerdeyî' },
      { id: 'conversational', name: 'Dengê Axaftinê' },
      { id: 'traditional', name: 'Dengê Kevneşopî' }
    ],
    'ku-hawrami': [
      { id: 'news', name: 'دەنگی هەواڵ' },
      { id: 'storyteller', name: 'دەنگی چیرۆکبێژ' },
      { id: 'traditional', name: 'دەنگی نەریتی' },
      { id: 'religious', name: 'دەنگی ئایینی' }
    ]
  };

  const handleFileSelect = (event) => {
    const selectedFiles = Array.from(event.target.files);
    const audioFiles = selectedFiles.filter(file => {
      const ext = file.name.split('.').pop().toLowerCase();
      return ['wav', 'mp3', 'flac', 'm4a'].includes(ext);
    });

    setFiles(prev => [...prev, ...audioFiles]);
  };

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (files.length < 5) {
      setUploadStatus({
        type: 'error',
        message: direction === 'rtl' ? 
          'لانیکەم ٥ فایلی دەنگ پێویستە' : 
          'Kêmî 5 pelên dengî pêwîst in'
      });
      return;
    }

    if (!voiceConfig.name.trim()) {
      setUploadStatus({
        type: 'error',
        message: direction === 'rtl' ? 
          'ناوی دەنگ پێویستە' : 
          'Navê dengî pêwîst e'
      });
      return;
    }

    setUploading(true);
    setUploadStatus({
      type: 'info',
      message: direction === 'rtl' ? 
        'فایلەکان بارکراو دەکرێن...' : 
        'Pel tên barkirin...'
    });

    try {
      const formData = new FormData();
      
      // Add files
      files.forEach(file => {
        formData.append('audio_files', file);
      });

      // Add configuration
      formData.append('config', JSON.stringify(voiceConfig));

      const response = await fetch('/api/voices/upload', {
        method: 'POST',
        body: formData
      });

      const result = await response.json();

      if (response.ok) {
        setUploadStatus({
          type: 'success',
          message: direction === 'rtl' ? 
            'دەنگەکە بە سەرکەوتوویی بارکرا! ڕاهێنان دەست پێکرد.' : 
            'Deng bi serkeftinê hate barkirin! Perwerde dest pê kir.'
        });
        
        // Reset form after successful upload
        setTimeout(() => {
          setFiles([]);
          setVoiceConfig({
            name: '',
            description: '',
            type: 'news',
            language: language
          });
          setUploadStatus(null);
        }, 3000);
      } else {
        throw new Error(result.error || 'Upload failed');
      }
    } catch (error) {
      setUploadStatus({
        type: 'error',
        message: direction === 'rtl' ? 
          `هەڵە: ${error.message}` : 
          `Xeletî: ${error.message}`
      });
    } finally {
      setUploading(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-blue-600" />
              {direction === 'rtl' ? 'زیادکردنی دەنگی تایبەت' : 'Zêdekirina Dengê Taybetî'}
            </CardTitle>
            <CardDescription>
              {direction === 'rtl' ? 
                'دەنگی خۆت بارکە بۆ دروستکردنی TTS ی تایبەت' : 
                'Dengê xwe bar bike ji bo çêkirina TTS ya taybetî'
              }
            </CardDescription>
          </div>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Voice Configuration */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="voice-name">
              {direction === 'rtl' ? 'ناوی دەنگ' : 'Navê Dengî'}
            </Label>
            <Input
              id="voice-name"
              placeholder={direction === 'rtl' ? 'ناوی دەنگەکە...' : 'Navê dengê...'}
              value={voiceConfig.name}
              onChange={(e) => setVoiceConfig(prev => ({ ...prev, name: e.target.value }))}
              dir={direction}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="voice-type">
              {direction === 'rtl' ? 'جۆری دەنگ' : 'Cureya Dengî'}
            </Label>
            <Select 
              value={voiceConfig.type} 
              onValueChange={(value) => setVoiceConfig(prev => ({ ...prev, type: value }))}
            >
              <SelectTrigger id="voice-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {voiceTypes[language]?.map((type) => (
                  <SelectItem key={type.id} value={type.id}>
                    {type.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="voice-description">
            {direction === 'rtl' ? 'پێناسەی دەنگ' : 'Pênaseya Dengî'}
          </Label>
          <Textarea
            id="voice-description"
            placeholder={direction === 'rtl' ? 
              'کورتە پێناسەیەک لەسەر دەنگەکە...' : 
              'Pênaseyek kurt li ser dengê...'
            }
            value={voiceConfig.description}
            onChange={(e) => setVoiceConfig(prev => ({ ...prev, description: e.target.value }))}
            dir={direction}
          />
        </div>

        {/* File Upload */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>
              {direction === 'rtl' ? 'فایلە دەنگییەکان' : 'Pelên Dengî'}
            </Label>
            <span className="text-sm text-gray-500">
              {files.length}/50+ {direction === 'rtl' ? 'فایل' : 'pel'}
            </span>
          </div>

          {/* Upload Area */}
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-400 transition-colors">
            <input
              type="file"
              multiple
              accept=".wav,.mp3,.flac,.m4a"
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <FileAudio className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-700 mb-2">
                {direction === 'rtl' ? 
                  'فایلەکان بخەرە ئێرە یان کلیک بکە' : 
                  'Pelan li vir bixe an klîk bike'
                }
              </p>
              <p className="text-sm text-gray-500">
                WAV, MP3, FLAC, M4A - {direction === 'rtl' ? 'هەر فایلێک تا ١٠ مێگابایت' : 'Her pel heta 10 MB'}
              </p>
            </label>
          </div>

          {/* File List */}
          {files.length > 0 && (
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {files.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex items-center gap-2">
                    <FileAudio className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium">{file.name}</span>
                    <span className="text-xs text-gray-500">({formatFileSize(file.size)})</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(index)}
                    className="h-6 w-6 p-0"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Guidelines */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-medium text-blue-900 mb-2">
            {direction === 'rtl' ? 'ڕێنماییەکان:' : 'Rêberî:'}
          </h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• {direction === 'rtl' ? 'لانیکەم ٥ فایل، باشترە ٥٠+' : 'Kêmî 5 pel, baştir e 50+'}</li>
            <li>• {direction === 'rtl' ? 'هەر فایلێک ٥-١٥ چرکە' : 'Her pel 5-15 çirke'}</li>
            <li>• {direction === 'rtl' ? 'کوالیتی بەرز (٤٤.١ kHz)' : 'Kalîteya bilind (44.1 kHz)'}</li>
            <li>• {direction === 'rtl' ? 'ژینگەی بێدەنگ' : 'Jîngeya bêdeng'}</li>
            <li>• {direction === 'rtl' ? 'دەنگێکی ڕوون و سروشتی' : 'Dengekî zelal û xwezayî'}</li>
          </ul>
        </div>

        {/* Status Message */}
        {uploadStatus && (
          <div className={`p-3 rounded-md flex items-center gap-2 ${
            uploadStatus.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' :
            uploadStatus.type === 'error' ? 'bg-red-50 text-red-700 border border-red-200' :
            'bg-blue-50 text-blue-700 border border-blue-200'
          }`}>
            {uploadStatus.type === 'success' ? (
              <CheckCircle className="h-4 w-4" />
            ) : uploadStatus.type === 'error' ? (
              <AlertCircle className="h-4 w-4" />
            ) : (
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
            )}
            <span className="text-sm">{uploadStatus.message}</span>
          </div>
        )}

        {/* Upload Button */}
        <Button
          onClick={handleUpload}
          disabled={uploading || files.length < 5 || !voiceConfig.name.trim()}
          className="w-full"
          size="lg"
        >
          {uploading ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2 rtl:ml-2 rtl:mr-0"></div>
              {direction === 'rtl' ? 'بارکراو دەکرێت...' : 'Tê barkirin...'}
            </>
          ) : (
            <>
              <Upload className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
              {direction === 'rtl' ? 'دەنگ بارکە' : 'Dengê Bar Bike'}
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default VoiceUpload;

