import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, MapPin, Globe, ExternalLink } from 'lucide-react';
import { getTranslation, getLanguageDirection } from '../utils/translations';

const NewsTimeline = ({ language = 'ku-sorani' }) => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('kurdistan');

  const direction = getLanguageDirection(language);
  const t = (key) => getTranslation(language, key);

  useEffect(() => {
    fetchNews();
  }, [language, activeTab]);

  const fetchNews = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/news?category=${activeTab}&language=${language}`);
      if (response.ok) {
        const data = await response.json();
        setNews(data.articles || []);
      } else {
        // Fallback to mock data if API fails
        setNews(getMockNews());
      }
    } catch (error) {
      console.error('Error fetching news:', error);
      setNews(getMockNews());
    } finally {
      setLoading(false);
    }
  };

  const getMockNews = () => {
    const mockData = {
      'ku-sorani': {
        kurdistan: [
          {
            title: 'گەشەپێدانی تەکنەلۆژیا لە کوردستان',
            description: 'پڕۆژەی نوێی تەکنەلۆژیا لە هەولێر دەست پێکرد',
            time: '٢ کاتژمێر لەمەوپێش',
            source: 'کوردستان ٢٤'
          },
          {
            title: 'کۆنفرانسی نێودەوڵەتی لە سلێمانی',
            description: 'کۆنفرانسێکی گرنگ لەسەر ئابووری ئەنجام درا',
            time: '٤ کاتژمێر لەمەوپێش',
            source: 'رووداو'
          },
          {
            title: 'پڕۆژەی نوێی خوێندن',
            description: 'زانکۆی نوێ لە دهۆک کرایەوە',
            time: '٦ کاتژمێر لەمەوپێش',
            source: 'کوردپرێس'
          }
        ],
        world: [
          {
            title: 'گەشەپێدانی ژیری دەستکردەوە',
            description: 'تەکنەلۆژیای نوێی AI لە جیهاندا',
            time: '١ کاتژمێر لەمەوپێش',
            source: 'BBC کوردی'
          },
          {
            title: 'کۆنفرانسی کەشووهەوا',
            description: 'کۆنفرانسی نێودەوڵەتی لەسەر گۆڕانی کەشووهەوا',
            time: '٣ کاتژمێر لەمەوپێش',
            source: 'ڤۆیس ئۆف ئەمریکا'
          }
        ]
      },
      'ku-kurmanji': {
        kurdistan: [
          {
            title: 'Pêşveçûna Teknolojiyê li Kurdistanê',
            description: 'Projeya nû ya teknolojiyê li Hewlêrê dest pê kir',
            time: '2 saet berê',
            source: 'Kurdistan 24'
          },
          {
            title: 'Konferansa Navneteweyî li Silêmaniyê',
            description: 'Konferansa girîng li ser aboriyê hate kirin',
            time: '4 saet berê',
            source: 'Rudaw'
          },
          {
            title: 'Projeya Nû ya Perwerdehiyê',
            description: 'Zanîngeha nû li Duhokê hate vekirin',
            time: '6 saet berê',
            source: 'Kurdpress'
          }
        ],
        world: [
          {
            title: 'Pêşveçûna Aqilê Destî',
            description: 'Teknolojiya nû ya AI li cîhanê',
            time: '1 saet berê',
            source: 'BBC Kurdî'
          },
          {
            title: 'Konferansa Avhewayê',
            description: 'Konferansa navneteweyî li ser guherina avhewayê',
            time: '3 saet berê',
            source: 'Voice of America'
          }
        ]
      },
      'ku-hawrami': {
        kurdistan: [
          {
            title: 'پێشکەوتنی تەکنەلۆژیا لە کوردستان',
            description: 'پڕۆژەی نوێی تەکنەلۆژیا لە هەولێر دەست پێکرد',
            time: '٢ کاتژمێر لەمەوپێش',
            source: 'کوردستان ٢٤'
          },
          {
            title: 'کۆنفرانسی نێودەوڵەتی لە سلێمانی',
            description: 'کۆنفرانسێکی گرنگ لەسەر ئابووری ئەنجام درا',
            time: '٤ کاتژمێر لەمەوپێش',
            source: 'رووداو'
          }
        ],
        world: [
          {
            title: 'پێشکەوتنی ژیری دەستکردەوە',
            description: 'تەکنەلۆژیای نوێی AI لە جیهاندا',
            time: '١ کاتژمێر لەمەوپێش',
            source: 'BBC کوردی'
          }
        ]
      }
    };

    return mockData[language]?.[activeTab] || [];
  };

  const formatTime = (timeStr) => {
    // This would normally format time based on language
    return timeStr;
  };

  return (
    <Card className="h-fit">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-blue-600" />
          {t('newsTitle')}
        </CardTitle>
        <CardDescription>
          {direction === 'rtl' ? 'کۆتا هەواڵەکان' : 'Nûçeyên dawî'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Tab Navigation */}
        <div className="flex space-x-1 rtl:space-x-reverse mb-4 bg-gray-100 rounded-lg p-1">
          <Button
            variant={activeTab === 'kurdistan' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('kurdistan')}
            className="flex-1 text-xs"
          >
            <MapPin className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0" />
            {t('newsKurdistan')}
          </Button>
          <Button
            variant={activeTab === 'world' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('world')}
            className="flex-1 text-xs"
          >
            <Globe className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0" />
            {t('newsWorld')}
          </Button>
        </div>

        {/* News List */}
        <div className="space-y-4">
          {loading ? (
            // Loading skeleton
            Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mb-1"></div>
                <div className="h-3 bg-gray-200 rounded w-3/4"></div>
              </div>
            ))
          ) : news.length > 0 ? (
            news.map((article, index) => (
              <div
                key={index}
                className="border-l-4 border-blue-500 rtl:border-l-0 rtl:border-r-4 pl-4 rtl:pr-4 rtl:pl-0 pb-4 last:pb-0 animate-slide-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <h4 className="font-medium text-sm text-gray-900 mb-1 leading-tight">
                  {article.title}
                </h4>
                <p className="text-xs text-gray-600 mb-2 leading-relaxed">
                  {article.description}
                </p>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span>{formatTime(article.time)}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {article.source}
                  </Badge>
                </div>
                {article.url && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="mt-2 p-0 h-auto text-xs text-blue-600 hover:text-blue-800"
                    onClick={() => window.open(article.url, '_blank')}
                  >
                    {t('readMore')}
                    <ExternalLink className="h-3 w-3 ml-1 rtl:mr-1 rtl:ml-0" />
                  </Button>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Globe className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">
                {direction === 'rtl' ? 'هەواڵ نەدۆزرایەوە' : 'Nûçe nehate dîtin'}
              </p>
            </div>
          )}
        </div>

        {/* Refresh Button */}
        <Button
          variant="outline"
          size="sm"
          onClick={fetchNews}
          className="w-full mt-4 text-xs"
          disabled={loading}
        >
          {loading ? (
            direction === 'rtl' ? 'بارکردن...' : 'Tê barkirin...'
          ) : (
            direction === 'rtl' ? 'نوێکردنەوە' : 'Nûkirin'
          )}
        </Button>
      </CardContent>
    </Card>
  );
};

export default NewsTimeline;

