import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

const languages = [
  { 
    code: 'ku-sorani', 
    name: 'سۆرانی', 
    flag: '🟡🔴🟢',
    direction: 'rtl'
  },
  { 
    code: 'ku-kurmanji', 
    name: 'Kurmancî', 
    flag: '🟡🔴🟢',
    direction: 'ltr'
  },
  { 
    code: 'ku-hawrami', 
    name: 'هەورامی', 
    flag: '🟡🔴🟢',
    direction: 'rtl'
  }
];

const LanguageSelector = ({ selectedLanguage, onLanguageChange, className = "" }) => {
  const currentLang = languages.find(lang => lang.code === selectedLanguage) || languages[0];

  return (
    <div className={`space-y-2 ${className}`}>
      <Label htmlFor="language-select" className="text-sm font-medium">
        {currentLang.direction === 'rtl' ? 'زمان هەڵبژێرە' : 'Zimanê hilbijêre'}
      </Label>
      <Select value={selectedLanguage} onValueChange={onLanguageChange}>
        <SelectTrigger id="language-select" className="w-full">
          <SelectValue placeholder={currentLang.direction === 'rtl' ? 'زمانێک هەڵبژێرە' : 'Zimanekî hilbijêre'} />
        </SelectTrigger>
        <SelectContent>
          {languages.map((language) => (
            <SelectItem key={language.code} value={language.code}>
              <div className="flex items-center gap-2">
                <span>{language.flag}</span>
                <span className={language.direction === 'rtl' ? 'font-kurdish' : 'font-latin'}>
                  {language.name}
                </span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default LanguageSelector;

