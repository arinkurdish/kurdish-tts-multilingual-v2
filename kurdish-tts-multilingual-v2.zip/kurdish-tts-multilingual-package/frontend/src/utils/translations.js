export const translations = {
  'ku-sorani': {
    // Header
    title: 'گۆڕینی نووسینی کوردی بۆ دەنگ',
    subtitle: 'دەقی کوردی بنووسە و بیگۆڕە بۆ دەنگی سروشتی',
    
    // Main form
    textLabel: 'دەقی کوردی بنووسە',
    textPlaceholder: 'لێرەدا دەقی کوردیت بنووسە...',
    voiceLabel: 'جۆری دەنگ هەڵبژێرە',
    voicePlaceholder: 'دەنگێک هەڵبژێرە',
    convertButton: 'گۆڕین بۆ دەنگ',
    
    // Voice types
    voices: {
      news: 'دەنگی هەواڵ',
      storyteller: 'دەنگی چیرۆکبێژ', 
      singer: 'دەنگی گۆرانیبێژ',
      male: 'دەنگی ئاسایی پیاو',
      female: 'دەنگی ئاسایی ژن'
    },
    
    // Audio player
    audioGenerated: 'دەنگەکە دروست کرا!',
    downloadAudio: 'دابەزاندنی دەنگ',
    
    // Download formats
    downloadFormats: {
      mp3: 'دابەزاندن وەک MP3',
      wav: 'دابەزاندن وەک WAV', 
      ogg: 'دابەزاندن وەک OGG',
      m4a: 'دابەزاندن وەک M4A',
      flac: 'دابەزاندن وەک FLAC'
    },
    
    // News section
    newsTitle: 'هەواڵە نوێکان',
    newsKurdistan: 'هەواڵی کوردستان',
    newsWorld: 'هەواڵی جیهان',
    readMore: 'زیاتر بخوێنەرەوە',
    
    // Status messages
    processing: 'دەنگەکە دروست دەکرێت...',
    success: 'دەنگەکە بە سەرکەوتوویی دروست کرا!',
    error: 'هەڵەیەک ڕوویدا. تکایە دووبارە تاقی بکەرەوە.',
    
    // Footer
    poweredBy: 'بە هێزی ژیری دەستکردەوە',
    madeWith: 'دروستکراوە بە',
    
    // Language
    language: 'زمان',
    selectLanguage: 'زمان هەڵبژێرە'
  },
  
  'ku-kurmanji': {
    // Header
    title: 'Veguheztina Nivîsê ya Kurdî bo Deng',
    subtitle: 'Nivîsê kurdî binivîse û veguherîne dengê xwezayî',
    
    // Main form
    textLabel: 'Nivîsê kurdî binivîse',
    textPlaceholder: 'Li vir nivîsê kurdî binivîse...',
    voiceLabel: 'Cureya dengî hilbijêre',
    voicePlaceholder: 'Dengekî hilbijêre',
    convertButton: 'Veguherîne bo Deng',
    
    // Voice types
    voices: {
      news: 'Dengê Nûçeyan',
      storyteller: 'Dengê Çîrokbêj',
      singer: 'Dengê Stran',
      male: 'Dengê Asayî Mêr',
      female: 'Dengê Asayî Jin'
    },
    
    // Audio player
    audioGenerated: 'Deng hate çêkirin!',
    downloadAudio: 'Daxistina Dengî',
    
    // Download formats
    downloadFormats: {
      mp3: 'Daxe wek MP3',
      wav: 'Daxe wek WAV',
      ogg: 'Daxe wek OGG', 
      m4a: 'Daxe wek M4A',
      flac: 'Daxe wek FLAC'
    },
    
    // News section
    newsTitle: 'Nûçeyên Nû',
    newsKurdistan: 'Nûçeyên Kurdistanê',
    newsWorld: 'Nûçeyên Cîhanê',
    readMore: 'Zêdetir bixwîne',
    
    // Status messages
    processing: 'Deng tê çêkirin...',
    success: 'Deng bi serkeftinê hate çêkirin!',
    error: 'Xeletîyek çêbû. Ji kerema xwe dîsa biceribîne.',
    
    // Footer
    poweredBy: 'Bi hêza Aqilê Destî',
    madeWith: 'Çêkirî bi',
    
    // Language
    language: 'Ziman',
    selectLanguage: 'Zimanê hilbijêre'
  },
  
  'ku-hawrami': {
    // Header
    title: 'وەرگێڕانی نووسراوی کوردی بۆ دەنگ',
    subtitle: 'نووسراوی کوردی بنووسە و بیگۆڕە بۆ دەنگی سروشتی',
    
    // Main form
    textLabel: 'نووسراوی کوردی بنووسە',
    textPlaceholder: 'لێرەدا نووسراوی کوردیت بنووسە...',
    voiceLabel: 'جۆری دەنگ هەڵبژێرە',
    voicePlaceholder: 'دەنگێک هەڵبژێرە',
    convertButton: 'گۆڕین بۆ دەنگ',
    
    // Voice types
    voices: {
      news: 'دەنگی هەواڵ',
      storyteller: 'دەنگی چیرۆکبێژ',
      singer: 'دەنگی گۆرانیبێژ', 
      male: 'دەنگی ئاسایی پیاو',
      female: 'دەنگی ئاسایی ژن'
    },
    
    // Audio player
    audioGenerated: 'دەنگەکە دروست کرا!',
    downloadAudio: 'دابەزاندنی دەنگ',
    
    // Download formats
    downloadFormats: {
      mp3: 'دابەزاندن وەک MP3',
      wav: 'دابەزاندن وەک WAV',
      ogg: 'دابەزاندن وەک OGG',
      m4a: 'دابەزاندن وەک M4A', 
      flac: 'دابەزاندن وەک FLAC'
    },
    
    // News section
    newsTitle: 'هەواڵە نوێکان',
    newsKurdistan: 'هەواڵی کوردستان',
    newsWorld: 'هەواڵی جیهان',
    readMore: 'زیاتر بخوێنەرەوە',
    
    // Status messages
    processing: 'دەنگەکە دروست دەکرێت...',
    success: 'دەنگەکە بە سەرکەوتوویی دروست کرا!',
    error: 'هەڵەیەک ڕوویدا. تکایە دووبارە تاقی بکەرەوە.',
    
    // Footer
    poweredBy: 'بە هێزی ژیری دەستکردەوە',
    madeWith: 'دروستکراوە بە',
    
    // Language
    language: 'زمان',
    selectLanguage: 'زمان هەڵبژێرە'
  }
};

export const getTranslation = (language, key) => {
  const keys = key.split('.');
  let value = translations[language];
  
  for (const k of keys) {
    if (value && typeof value === 'object') {
      value = value[k];
    } else {
      return key; // Return key if translation not found
    }
  }
  
  return value || key;
};

export const getLanguageDirection = (language) => {
  return language === 'ku-kurmanji' ? 'ltr' : 'rtl';
};

export const getLanguageName = (language) => {
  const names = {
    'ku-sorani': 'سۆرانی',
    'ku-kurmanji': 'Kurmancî', 
    'ku-hawrami': 'هەورامی'
  };
  return names[language] || 'سۆرانی';
};

