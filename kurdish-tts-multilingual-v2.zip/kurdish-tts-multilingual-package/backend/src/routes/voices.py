from flask import Blueprint, request, jsonify, send_file
import os
import json
import tempfile
import io
from werkzeug.utils import secure_filename
from datetime import datetime

voices_bp = Blueprint('voices', __name__)

# Custom voices storage (in production, this would be a database)
CUSTOM_VOICES = {
    'ku-sorani': {
        'custom_voices': [
            {
                'id': 'sorani_news_1',
                'name': 'دەنگی هەواڵی تایبەت',
                'description': 'دەنگێکی تایبەت بۆ خوێندنەوەی هەواڵ',
                'language': 'ku-sorani',
                'type': 'news',
                'quality': 'high',
                'sample_url': '/api/voices/samples/sorani_news_1.mp3',
                'created_at': '2024-01-15',
                'created_by': 'user_demo'
            },
            {
                'id': 'sorani_story_1', 
                'name': 'دەنگی چیرۆکبێژی تایبەت',
                'description': 'دەنگێکی نەرم بۆ گێڕانەوەی چیرۆک',
                'language': 'ku-sorani',
                'type': 'storyteller',
                'quality': 'high',
                'sample_url': '/api/voices/samples/sorani_story_1.mp3',
                'created_at': '2024-01-10',
                'created_by': 'user_demo'
            }
        ]
    },
    'ku-kurmanji': {
        'custom_voices': [
            {
                'id': 'kurmanji_news_1',
                'name': 'Dengê Nûçeyên Taybetî',
                'description': 'Dengek taybetî ji bo xwendina nûçeyan',
                'language': 'ku-kurmanji',
                'type': 'news',
                'quality': 'high',
                'sample_url': '/api/voices/samples/kurmanji_news_1.mp3',
                'created_at': '2024-01-12',
                'created_by': 'user_demo'
            }
        ]
    },
    'ku-hawrami': {
        'custom_voices': [
            {
                'id': 'hawrami_traditional_1',
                'name': 'دەنگی نەریتی هەورامی',
                'description': 'دەنگێکی نەریتی بۆ گۆرانی و چیرۆکی هەورامی',
                'language': 'ku-hawrami',
                'type': 'traditional',
                'quality': 'medium',
                'sample_url': '/api/voices/samples/hawrami_traditional_1.mp3',
                'created_at': '2024-01-08',
                'created_by': 'user_demo'
            }
        ]
    }
}

@voices_bp.route('/custom', methods=['GET'])
def get_custom_voices():
    """Get custom voices by language"""
    language = request.args.get('language', 'ku-sorani')
    voice_type = request.args.get('type', None)
    
    if language not in CUSTOM_VOICES:
        return jsonify({
            'language': language,
            'custom_voices': [],
            'total': 0
        })
    
    voices = CUSTOM_VOICES[language]['custom_voices']
    
    # Filter by type if specified
    if voice_type:
        voices = [v for v in voices if v['type'] == voice_type]
    
    return jsonify({
        'language': language,
        'custom_voices': voices,
        'total': len(voices),
        'available_types': list(set(v['type'] for v in CUSTOM_VOICES[language]['custom_voices']))
    })

@voices_bp.route('/custom/<voice_id>', methods=['GET'])
def get_custom_voice(voice_id):
    """Get specific custom voice details"""
    for language, data in CUSTOM_VOICES.items():
        for voice in data['custom_voices']:
            if voice['id'] == voice_id:
                return jsonify({
                    'success': True,
                    'voice': voice
                })
    
    return jsonify({'error': 'Voice not found'}), 404

@voices_bp.route('/upload', methods=['POST'])
def upload_custom_voice():
    """Upload a custom voice model"""
    try:
        # Check if files are present
        if 'audio_files' not in request.files:
            return jsonify({'error': 'No audio files provided'}), 400
        
        if 'config' not in request.form:
            return jsonify({'error': 'Voice configuration required'}), 400
        
        # Parse configuration
        try:
            config = json.loads(request.form['config'])
        except json.JSONDecodeError:
            return jsonify({'error': 'Invalid configuration format'}), 400
        
        # Validate required fields
        required_fields = ['name', 'language', 'type', 'description']
        for field in required_fields:
            if field not in config:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Validate language
        if config['language'] not in CUSTOM_VOICES:
            return jsonify({'error': 'Unsupported language'}), 400
        
        # Get uploaded files
        audio_files = request.files.getlist('audio_files')
        
        if len(audio_files) < 5:
            return jsonify({'error': 'Minimum 5 audio files required for voice training'}), 400
        
        # Validate audio files
        allowed_extensions = {'wav', 'mp3', 'flac', 'm4a'}
        for file in audio_files:
            if file.filename == '':
                return jsonify({'error': 'Empty filename not allowed'}), 400
            
            ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
            if ext not in allowed_extensions:
                return jsonify({'error': f'File type .{ext} not supported. Use: {", ".join(allowed_extensions)}'}), 400
        
        # Generate voice ID
        voice_id = f"{config['language']}_{config['type']}_{int(datetime.now().timestamp())}"
        
        # In a real implementation, this would:
        # 1. Save audio files to storage
        # 2. Process and train the voice model
        # 3. Generate voice samples
        # 4. Store voice metadata in database
        
        # For demo, create a mock voice entry
        new_voice = {
            'id': voice_id,
            'name': config['name'],
            'description': config['description'],
            'language': config['language'],
            'type': config['type'],
            'quality': 'processing',  # Would be updated after training
            'sample_url': f'/api/voices/samples/{voice_id}.mp3',
            'created_at': datetime.now().strftime('%Y-%m-%d'),
            'created_by': config.get('created_by', 'anonymous'),
            'file_count': len(audio_files),
            'status': 'training'  # processing, ready, failed
        }
        
        # Add to storage (in production, save to database)
        if config['language'] not in CUSTOM_VOICES:
            CUSTOM_VOICES[config['language']] = {'custom_voices': []}
        
        CUSTOM_VOICES[config['language']]['custom_voices'].append(new_voice)
        
        return jsonify({
            'success': True,
            'message': 'Voice upload successful. Training in progress.',
            'voice_id': voice_id,
            'voice': new_voice,
            'estimated_training_time': '15-30 minutes'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@voices_bp.route('/training-status/<voice_id>', methods=['GET'])
def get_training_status(voice_id):
    """Get voice training status"""
    for language, data in CUSTOM_VOICES.items():
        for voice in data['custom_voices']:
            if voice['id'] == voice_id:
                # Mock training progress
                import random
                progress = random.randint(10, 100)
                
                status = 'training'
                if progress >= 100:
                    status = 'ready'
                    voice['status'] = 'ready'
                    voice['quality'] = 'high'
                
                return jsonify({
                    'voice_id': voice_id,
                    'status': status,
                    'progress': progress,
                    'estimated_remaining': max(0, 30 - (progress * 0.3)),
                    'voice': voice
                })
    
    return jsonify({'error': 'Voice not found'}), 404

@voices_bp.route('/samples/<filename>')
def serve_voice_sample(filename):
    """Serve voice sample files"""
    try:
        # For demo purposes, create a simple audio file
        # In production, this would serve actual voice samples
        
        sample_rate = 44100
        duration = 5  # 5 seconds
        frequency = 440  # A4 note
        
        import struct
        import math
        
        # Generate simple sine wave
        frames = []
        for i in range(int(duration * sample_rate)):
            value = int(16383 * math.sin(2 * math.pi * frequency * i / sample_rate))
            frames.append(struct.pack('<h', value))
        
        # WAV file header
        wav_data = b'RIFF'
        wav_data += struct.pack('<I', 36 + len(frames) * 2)
        wav_data += b'WAVE'
        wav_data += b'fmt '
        wav_data += struct.pack('<I', 16)  # PCM
        wav_data += struct.pack('<H', 1)   # PCM format
        wav_data += struct.pack('<H', 1)   # Mono
        wav_data += struct.pack('<I', sample_rate)
        wav_data += struct.pack('<I', sample_rate * 2)
        wav_data += struct.pack('<H', 2)
        wav_data += struct.pack('<H', 16)
        wav_data += b'data'
        wav_data += struct.pack('<I', len(frames) * 2)
        wav_data += b''.join(frames)
        
        return send_file(
            io.BytesIO(wav_data),
            mimetype='audio/wav',
            as_attachment=False,
            download_name=filename
        )
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@voices_bp.route('/custom/<voice_id>', methods=['DELETE'])
def delete_custom_voice(voice_id):
    """Delete a custom voice"""
    for language, data in CUSTOM_VOICES.items():
        for i, voice in enumerate(data['custom_voices']):
            if voice['id'] == voice_id:
                # Remove voice from storage
                del data['custom_voices'][i]
                
                # In production, also delete:
                # - Voice model files
                # - Audio samples
                # - Database entries
                
                return jsonify({
                    'success': True,
                    'message': 'Voice deleted successfully',
                    'voice_id': voice_id
                })
    
    return jsonify({'error': 'Voice not found'}), 404

@voices_bp.route('/types', methods=['GET'])
def get_voice_types():
    """Get available voice types by language"""
    language = request.args.get('language', 'ku-sorani')
    
    voice_types = {
        'ku-sorani': [
            {'id': 'news', 'name': 'دەنگی هەواڵ', 'description': 'بۆ خوێندنەوەی هەواڵ و دەقی فەرمی'},
            {'id': 'storyteller', 'name': 'دەنگی چیرۆکبێژ', 'description': 'بۆ گێڕانەوەی چیرۆک و حەکایەت'},
            {'id': 'singer', 'name': 'دەنگی گۆرانیبێژ', 'description': 'بۆ گۆرانی و میوزیک'},
            {'id': 'educational', 'name': 'دەنگی پەروەردەیی', 'description': 'بۆ وانە و فێرکردن'},
            {'id': 'conversational', 'name': 'دەنگی گفتوگۆ', 'description': 'بۆ گفتوگۆی ئاسایی'},
            {'id': 'traditional', 'name': 'دەنگی نەریتی', 'description': 'بۆ گۆرانی و چیرۆکی نەریتی'}
        ],
        'ku-kurmanji': [
            {'id': 'news', 'name': 'Dengê Nûçeyan', 'description': 'Ji bo xwendina nûçe û nivîsên fermî'},
            {'id': 'storyteller', 'name': 'Dengê Çîrokbêj', 'description': 'Ji bo vegotin û çîrokan'},
            {'id': 'singer', 'name': 'Dengê Stran', 'description': 'Ji bo stran û mûzîk'},
            {'id': 'educational', 'name': 'Dengê Perwerdeyî', 'description': 'Ji bo ders û hînkirin'},
            {'id': 'conversational', 'name': 'Dengê Axaftinê', 'description': 'Ji bo axaftina asayî'},
            {'id': 'traditional', 'name': 'Dengê Kevneşopî', 'description': 'Ji bo stran û çîrokên kevneşopî'}
        ],
        'ku-hawrami': [
            {'id': 'news', 'name': 'دەنگی هەواڵ', 'description': 'بۆ خوێندنەوەی هەواڵ و دەقی فەرمی'},
            {'id': 'storyteller', 'name': 'دەنگی چیرۆکبێژ', 'description': 'بۆ گێڕانەوەی چیرۆک و حەکایەت'},
            {'id': 'traditional', 'name': 'دەنگی نەریتی', 'description': 'بۆ گۆرانی و چیرۆکی هەورامی'},
            {'id': 'religious', 'name': 'دەنگی ئایینی', 'description': 'بۆ دەقی ئایینی و نوێژ'}
        ]
    }
    
    types = voice_types.get(language, voice_types['ku-sorani'])
    
    return jsonify({
        'language': language,
        'voice_types': types,
        'total': len(types)
    })

@voices_bp.route('/guidelines', methods=['GET'])
def get_voice_guidelines():
    """Get voice recording guidelines"""
    language = request.args.get('language', 'ku-sorani')
    
    guidelines = {
        'ku-sorani': {
            'title': 'ڕێنمایی تۆمارکردنی دەنگ',
            'requirements': [
                'کوالیتی دەنگ: ٤٤.١ kHz یان زیاتر',
                'فۆرمات: WAV، FLAC، یان MP3 (٣٢٠ kbps)',
                'ماوە: هەر فایلێک ٥-١٥ چرکە',
                'ژمارەی فایل: لانیکەم ٥٠ فایل',
                'ژینگەی بێدەنگ: بێ دەنگی پاشبنەما',
                'خێرایی قسەکردن: ئاسایی و ڕوون'
            ],
            'tips': [
                'لە ژوورێکی بێدەنگدا تۆمار بکە',
                'مایکرۆفۆنێکی باش بەکار بهێنە',
                'دوور لە کۆمپیوتەر و ئامێرە کارەباییەکان بوەستە',
                'بە دەنگێکی سروشتی بخوێنەرەوە',
                'وشەکان بە ڕوونی دەربهێنە'
            ]
        },
        'ku-kurmanji': {
            'title': 'Rêberiya Tomarkirina Dengî',
            'requirements': [
                'Kalîteya dengî: 44.1 kHz an zêdetir',
                'Format: WAV, FLAC, an MP3 (320 kbps)',
                'Dem: Her pelekî 5-15 çirke',
                'Hejmara pelan: Kêmî 50 pel',
                'Jîngeha bêdeng: Bê dengê paşbingehê',
                'Leza axaftinê: Asayî û zelal'
            ],
            'tips': [
                'Li odeyek bêdengî de tomar bike',
                'Mîkrofoneke baş bi kar bîne',
                'Dûr ji komputer û amûrên kareba bisekinîne',
                'Bi dengekî xwezayî bixwîne',
                'Peyvan bi zelalbûnê derbixîne'
            ]
        },
        'ku-hawrami': {
            'title': 'ڕێنمایی تۆمارکردنی دەنگ',
            'requirements': [
                'کوالیتی دەنگ: ٤٤.١ kHz یان زیاتر',
                'فۆرمات: WAV، FLAC، یان MP3',
                'ماوە: هەر فایلێک ٥-١٥ چرکە',
                'ژمارەی فایل: لانیکەم ٣٠ فایل',
                'ژینگەی بێدەنگ: بێ دەنگی پاشبنەما'
            ],
            'tips': [
                'لە ژوورێکی بێدەنگدا تۆمار بکە',
                'بە شێوازی نەریتی هەورامی بخوێنەرەوە',
                'گرنگی بە لەهجەی ڕاست بدە'
            ]
        }
    }
    
    guide = guidelines.get(language, guidelines['ku-sorani'])
    
    return jsonify({
        'language': language,
        'guidelines': guide
    })

@voices_bp.route('/stats', methods=['GET'])
def get_voice_stats():
    """Get voice statistics"""
    stats = {
        'total_custom_voices': 0,
        'by_language': {},
        'by_type': {},
        'recent_uploads': []
    }
    
    for language, data in CUSTOM_VOICES.items():
        voices = data['custom_voices']
        stats['total_custom_voices'] += len(voices)
        stats['by_language'][language] = len(voices)
        
        for voice in voices:
            voice_type = voice['type']
            if voice_type not in stats['by_type']:
                stats['by_type'][voice_type] = 0
            stats['by_type'][voice_type] += 1
            
            # Add to recent uploads (last 5)
            if len(stats['recent_uploads']) < 5:
                stats['recent_uploads'].append({
                    'id': voice['id'],
                    'name': voice['name'],
                    'language': voice['language'],
                    'created_at': voice['created_at']
                })
    
    return jsonify(stats)

