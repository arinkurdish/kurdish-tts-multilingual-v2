from flask import Blueprint, jsonify, request

user_bp = Blueprint('user', __name__)

@user_bp.route('/', methods=['GET'])
def get_users():
    """Get user information"""
    return jsonify({
        'message': 'User management endpoint',
        'version': '2.0.0',
        'features': ['Multi-language support', 'Custom voices', 'News integration']
    })

@user_bp.route('/profile', methods=['GET'])
def get_profile():
    """Get user profile"""
    return jsonify({
        'user': {
            'id': 1,
            'name': 'Demo User',
            'language_preference': 'ku-sorani',
            'custom_voices': 3,
            'usage_stats': {
                'total_conversions': 45,
                'total_downloads': 23,
                'favorite_voice': 'news'
            }
        }
    })

@user_bp.route('/preferences', methods=['GET', 'POST'])
def user_preferences():
    """Get or update user preferences"""
    if request.method == 'GET':
        return jsonify({
            'language': 'ku-sorani',
            'default_voice': 'news',
            'audio_format': 'mp3',
            'auto_download': False,
            'news_categories': ['kurdistan', 'world']
        })
    else:
        # Update preferences
        data = request.get_json()
        return jsonify({
            'success': True,
            'message': 'Preferences updated successfully',
            'preferences': data
        })

