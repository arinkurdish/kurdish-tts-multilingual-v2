from flask import Blueprint, request, jsonify
import time
from datetime import datetime, timedelta
import random

news_bp = Blueprint('news', __name__)

# Real news sources for different languages
NEWS_SOURCES = {
    'ku-sorani': [
        {
            'name': 'کوردستان ٢٤',
            'url': 'https://www.kurdistan24.net',
            'rss': 'https://www.kurdistan24.net/rss',
            'type': 'news',
            'language': 'ku-sorani'
        },
        {
            'name': 'رووداو',
            'url': 'https://www.rudaw.net',
            'rss': 'https://www.rudaw.net/rss',
            'type': 'news',
            'language': 'ku-sorani'
        },
        {
            'name': 'کوردپرێس',
            'url': 'https://www.kurdpress.com',
            'type': 'news',
            'language': 'ku-sorani'
        },
        {
            'name': 'BBC کوردی',
            'url': 'https://www.bbc.com/kurdish',
            'type': 'international',
            'language': 'ku-sorani'
        },
        {
            'name': 'ڤۆیس ئۆف ئەمریکا',
            'url': 'https://www.voanews.com/kurdish',
            'type': 'international',
            'language': 'ku-sorani'
        },
        {
            'name': 'مێدیا نیوز',
            'url': 'https://medyanews.net',
            'type': 'news',
            'language': 'ku-sorani'
        }
    ],
    'ku-kurmanji': [
        {
            'name': 'Kurdistan 24',
            'url': 'https://www.kurdistan24.net',
            'rss': 'https://www.kurdistan24.net/rss',
            'type': 'news',
            'language': 'ku-kurmanji'
        },
        {
            'name': 'Rudaw',
            'url': 'https://www.rudaw.net',
            'rss': 'https://www.rudaw.net/rss',
            'type': 'news',
            'language': 'ku-kurmanji'
        },
        {
            'name': 'VOA Kurmanji',
            'url': 'https://www.dengeamerika.com',
            'type': 'international',
            'language': 'ku-kurmanji'
        },
        {
            'name': 'ANF News',
            'url': 'https://anfenglishmobile.com',
            'type': 'news',
            'language': 'ku-kurmanji'
        },
        {
            'name': 'Medya News',
            'url': 'https://medyanews.net',
            'type': 'news',
            'language': 'ku-kurmanji'
        }
    ],
    'ku-hawrami': [
        {
            'name': 'کوردستان ٢٤',
            'url': 'https://www.kurdistan24.net',
            'type': 'news',
            'language': 'ku-hawrami'
        },
        {
            'name': 'رووداو',
            'url': 'https://www.rudaw.net',
            'type': 'news',
            'language': 'ku-hawrami'
        },
        {
            'name': 'BBC کوردی',
            'url': 'https://www.bbc.com/kurdish',
            'type': 'international',
            'language': 'ku-hawrami'
        }
    ]
}

# Enhanced mock news data with more realistic content
NEWS_DATA = {
    'ku-sorani': {
        'kurdistan': [
            {
                'id': 1,
                'title': 'گەشەپێدانی تەکنەلۆژیا لە کوردستان',
                'description': 'پڕۆژەی نوێی تەکنەلۆژیا لە هەولێر دەست پێکرد کە مەبەستی گەشەپێدانی بواری تەکنەلۆژیا و دروستکردنی کارگەی نوێیە',
                'content': 'حکومەتی هەرێمی کوردستان پڕۆژەیەکی گەورەی تەکنەلۆژیای دەست پێکردووە لە هەولێر کە مەبەستی گەشەپێدانی بواری تەکنەلۆژیا و دروستکردنی کارگەی نوێیە بۆ گەنجانی کوردستان...',
                'time': '٢ کاتژمێر لەمەوپێش',
                'source': 'کوردستان ٢٤',
                'category': 'تەکنەلۆژیا',
                'url': 'https://www.kurdistan24.net',
                'image': '/api/news/images/tech-kurdistan.jpg',
                'views': 1250,
                'likes': 89
            },
            {
                'id': 2,
                'title': 'کۆنفرانسی نێودەوڵەتی لە سلێمانی',
                'description': 'کۆنفرانسێکی گرنگ لەسەر ئابووری لە زانکۆی سلێمانی ئەنجام درا بە بەشداری زانایانی نێودەوڵەتی',
                'content': 'لە زانکۆی سلێمانیدا کۆنفرانسێکی نێودەوڵەتی لەسەر گەشەپێدانی ئابووری ئەنجام درا بە بەشداری زانایان و پسپۆڕانی ئابووری لە چەندین وڵات...',
                'time': '٤ کاتژمێر لەمەوپێش',
                'source': 'رووداو',
                'category': 'ئابووری',
                'url': 'https://www.rudaw.net',
                'image': '/api/news/images/conference-suli.jpg',
                'views': 890,
                'likes': 67
            },
            {
                'id': 3,
                'title': 'پڕۆژەی نوێی خوێندن',
                'description': 'زانکۆی نوێ لە دهۆک کرایەوە بۆ خوێندنی تەکنەلۆژیا و ئەندازیاری',
                'content': 'لە پارێزگای دهۆکدا زانکۆیەکی نوێ کرایەوە کە تایبەتە بە خوێندنی تەکنەلۆژیا و ئەندازیاری بۆ گەنجانی هەرێم...',
                'time': '٦ کاتژمێر لەمەوپێش',
                'source': 'کوردپرێس',
                'category': 'خوێندن',
                'url': 'https://www.kurdpress.com',
                'image': '/api/news/images/university-duhok.jpg',
                'views': 654,
                'likes': 45
            },
            {
                'id': 4,
                'title': 'گەشەپێدانی کشتوکاڵ',
                'description': 'پڕۆژەی نوێی کشتوکاڵ لە کوردستان دەست پێکرد بۆ بەرهەمهێنانی زیاتر',
                'content': 'وەزارەتی کشتوکاڵی هەرێمی کوردستان پڕۆژەیەکی نوێی راگەیاند بۆ گەشەپێدانی کشتوکاڵ و بەرهەمهێنانی زیاتر...',
                'time': '٨ کاتژمێر لەمەوپێش',
                'source': 'هەواڵی کوردستان',
                'category': 'کشتوکاڵ',
                'url': '#',
                'image': '/api/news/images/agriculture.jpg',
                'views': 432,
                'likes': 28
            },
            {
                'id': 5,
                'title': 'پەیمانی نوێی نەوت',
                'description': 'پەیمانێکی نوێی نەوت لەگەڵ کۆمپانیایەکی نێودەوڵەتی واژۆ کرا',
                'content': 'حکومەتی هەرێمی کوردستان پەیمانێکی نوێی نەوت لەگەڵ کۆمپانیایەکی نێودەوڵەتی واژۆ کرد...',
                'time': '١٠ کاتژمێر لەمەوپێش',
                'source': 'کوردستان ٢٤',
                'category': 'وزە',
                'url': 'https://www.kurdistan24.net',
                'image': '/api/news/images/oil-contract.jpg',
                'views': 1100,
                'likes': 78
            }
        ],
        'world': [
            {
                'id': 6,
                'title': 'گەشەپێدانی ژیری دەستکردەوە',
                'description': 'تەکنەلۆژیای نوێی AI لە جیهاندا پێشکەوتنی زۆری کردووە لە بوارە جیاوازەکاندا',
                'content': 'کۆمپانیاکانی تەکنەلۆژیا لە جیهاندا پێشکەوتنی زۆریان لە بواری ژیری دەستکردەوەدا کردووە کە کاریگەری لەسەر ژیانی ڕۆژانە دەبێت...',
                'time': '١ کاتژمێر لەمەوپێش',
                'source': 'BBC کوردی',
                'category': 'تەکنەلۆژیا',
                'url': 'https://www.bbc.com/kurdish',
                'image': '/api/news/images/ai-world.jpg',
                'views': 2100,
                'likes': 156
            },
            {
                'id': 7,
                'title': 'کۆنفرانسی کەشووهەوا',
                'description': 'کۆنفرانسی نێودەوڵەتی لەسەر گۆڕانی کەشووهەوا لە دوبەی بەردەوامە',
                'content': 'لە شاری دوبەیدا کۆنفرانسی نێودەوڵەتی لەسەر گۆڕانی کەشووهەوا بەردەوامە بە بەشداری نوێنەرانی زیاتر لە ١٩٠ وڵات...',
                'time': '٣ کاتژمێر لەمەوپێش',
                'source': 'ڤۆیس ئۆف ئەمریکا',
                'category': 'ژینگە',
                'url': 'https://www.voanews.com/kurdish',
                'image': '/api/news/images/climate-conference.jpg',
                'views': 1450,
                'likes': 98
            },
            {
                'id': 8,
                'title': 'پێشکەوتن لە پزیشکی',
                'description': 'دۆزینەوەی نوێ لە بواری چارەسەری نەخۆشی شێرپەنجە',
                'content': 'زانایان دۆزینەوەیەکی گرنگیان لە بواری چارەسەری نەخۆشی شێرپەنجەدا کردووە کە ئومێدی نوێ دەداتە نەخۆشان...',
                'time': '٥ کاتژمێر لەمەوپێش',
                'source': 'ڕۆیتەرز',
                'category': 'پزیشکی',
                'url': '#',
                'image': '/api/news/images/medical-breakthrough.jpg',
                'views': 980,
                'likes': 72
            },
            {
                'id': 9,
                'title': 'گۆڕانکاری لە ئابووری جیهان',
                'description': 'ئابووری جیهان ڕووبەڕووی گۆڕانکاری گەورە دەبێتەوە',
                'content': 'پسپۆڕانی ئابووری ئاگادار دەکەنەوە کە ئابووری جیهان ڕووبەڕووی گۆڕانکاری گەورە دەبێتەوە...',
                'time': '٧ کاتژمێر لەمەوپێش',
                'source': 'BBC کوردی',
                'category': 'ئابووری',
                'url': 'https://www.bbc.com/kurdish',
                'image': '/api/news/images/global-economy.jpg',
                'views': 756,
                'likes': 54
            }
        ]
    },
    'ku-kurmanji': {
        'kurdistan': [
            {
                'id': 1,
                'title': 'Pêşveçûna Teknolojiyê li Kurdistanê',
                'description': 'Projeya nû ya teknolojiyê li Hewlêrê dest pê kir ku armanca wê pêşveçûna warê teknolojiyê û çêkirina kargehên nû ye',
                'content': 'Hikûmeta Herêma Kurdistanê projeyeke mezin a teknolojiyê dest pê kiriye li Hewlêrê ku armanca wê pêşveçûna warê teknolojiyê û çêkirina kargehên nû ye ji bo ciwanên Kurdistanê...',
                'time': '2 saet berê',
                'source': 'Kurdistan 24',
                'category': 'Teknolojî',
                'url': 'https://www.kurdistan24.net',
                'image': '/api/news/images/tech-kurdistan.jpg',
                'views': 1250,
                'likes': 89
            },
            {
                'id': 2,
                'title': 'Konferansa Navneteweyî li Silêmaniyê',
                'description': 'Konferansa girîng li ser aboriyê li Zanîngeha Silêmaniyê hate kirin bi beşdariya zanayên navneteweyî',
                'content': 'Li Zanîngeha Silêmaniyê konferansa navneteweyî li ser pêşveçûna aboriyê hate kirin bi beşdariya zanayan û pisporên aboriyê ji çend welatan...',
                'time': '4 saet berê',
                'source': 'Rudaw',
                'category': 'Aborî',
                'url': 'https://www.rudaw.net',
                'image': '/api/news/images/conference-suli.jpg',
                'views': 890,
                'likes': 67
            },
            {
                'id': 3,
                'title': 'Projeya Nû ya Perwerdehiyê',
                'description': 'Zanîngeha nû li Duhokê hate vekirin ji bo xwendina teknolojiyê û endezyariyê',
                'content': 'Li parêzgeha Duhokê zanîngeheke nû hate vekirin ku taybete bi xwendina teknolojiyê û endezyariyê ji bo ciwanên herêmê...',
                'time': '6 saet berê',
                'source': 'Kurdpress',
                'category': 'Perwerde',
                'url': 'https://www.kurdpress.com',
                'image': '/api/news/images/university-duhok.jpg',
                'views': 654,
                'likes': 45
            },
            {
                'id': 4,
                'title': 'Pêşveçûna Çandiniyê',
                'description': 'Projeya nû ya çandiniyê li Kurdistanê dest pê kir ji bo hilberîna zêdetir',
                'content': 'Wezareta Çandiniyê ya Herêma Kurdistanê projeyeke nû ragihand ji bo pêşveçûna çandiniyê û hilberîna zêdetir...',
                'time': '8 saet berê',
                'source': 'Nûçeyên Kurdistanê',
                'category': 'Çandinî',
                'url': '#',
                'image': '/api/news/images/agriculture.jpg',
                'views': 432,
                'likes': 28
            }
        ],
        'world': [
            {
                'id': 5,
                'title': 'Pêşveçûna Aqilê Destî',
                'description': 'Teknolojiya nû ya AI li cîhanê pêşveçûnek mezin kiriye li warên cihê cihê',
                'content': 'Pargîdaniyên teknolojiyê li cîhanê pêşveçûnek mezin li warê aqilê destî kiriye ku bandoreke li ser jiyana rojane dike...',
                'time': '1 saet berê',
                'source': 'BBC Kurdî',
                'category': 'Teknolojî',
                'url': 'https://www.bbc.com/kurdish',
                'image': '/api/news/images/ai-world.jpg',
                'views': 2100,
                'likes': 156
            },
            {
                'id': 6,
                'title': 'Konferansa Avhewayê',
                'description': 'Konferansa navneteweyî li ser guherina avhewayê li Dubeyê berdewam e',
                'content': 'Li bajarê Dubeyê konferansa navneteweyî li ser guherina avhewayê berdewam e bi beşdariya nûnerên zêdetir ji 190 welatan...',
                'time': '3 saet berê',
                'source': 'Voice of America',
                'category': 'Jîngehî',
                'url': 'https://www.voanews.com/kurdish',
                'image': '/api/news/images/climate-conference.jpg',
                'views': 1450,
                'likes': 98
            },
            {
                'id': 7,
                'title': 'Pêşveçûn li Bijîşkiyê',
                'description': 'Dîtinek nû li warê dermankirina nexweşiya şêrpençeyê',
                'content': 'Zanayan dîtineke girîng li warê dermankirina nexweşiya şêrpençeyê kiriye ku hêvîyeke nû dide nexweşan...',
                'time': '5 saet berê',
                'source': 'Reuters',
                'category': 'Bijîşkî',
                'url': '#',
                'image': '/api/news/images/medical-breakthrough.jpg',
                'views': 980,
                'likes': 72
            }
        ]
    },
    'ku-hawrami': {
        'kurdistan': [
            {
                'id': 1,
                'title': 'پێشکەوتنی تەکنەلۆژیا لە کوردستان',
                'description': 'پڕۆژەی نوێی تەکنەلۆژیا لە هەولێر دەست پێکرد کە مەبەستی گەشەپێدانی بواری تەکنەلۆژیایە',
                'content': 'حکومەتی هەرێمی کوردستان پڕۆژەیەکی گەورەی تەکنەلۆژیای دەست پێکردووە لە هەولێر...',
                'time': '٢ کاتژمێر لەمەوپێش',
                'source': 'کوردستان ٢٤',
                'category': 'تەکنەلۆژیا',
                'url': 'https://www.kurdistan24.net',
                'image': '/api/news/images/tech-kurdistan.jpg',
                'views': 850,
                'likes': 62
            },
            {
                'id': 2,
                'title': 'کۆنفرانسی نێودەوڵەتی لە سلێمانی',
                'description': 'کۆنفرانسێکی گرنگ لەسەر ئابووری لە زانکۆی سلێمانی ئەنجام درا',
                'content': 'لە زانکۆی سلێمانیدا کۆنفرانسێکی نێودەوڵەتی لەسەر گەشەپێدانی ئابووری ئەنجام درا...',
                'time': '٤ کاتژمێر لەمەوپێش',
                'source': 'رووداو',
                'category': 'ئابووری',
                'url': 'https://www.rudaw.net',
                'image': '/api/news/images/conference-suli.jpg',
                'views': 620,
                'likes': 45
            },
            {
                'id': 3,
                'title': 'گەشەپێدانی کولتووری هەورامی',
                'description': 'پڕۆژەی نوێ بۆ پاراستنی کولتووری هەورامی دەست پێکرد',
                'content': 'پڕۆژەیەکی نوێ بۆ پاراستن و گەشەپێدانی کولتووری هەورامی دەست پێکرد...',
                'time': '٦ کاتژمێر لەمەوپێش',
                'source': 'کوردپرێس',
                'category': 'کولتوور',
                'url': 'https://www.kurdpress.com',
                'image': '/api/news/images/hawrami-culture.jpg',
                'views': 380,
                'likes': 28
            }
        ],
        'world': [
            {
                'id': 4,
                'title': 'پێشکەوتنی ژیری دەستکردەوە',
                'description': 'تەکنەلۆژیای نوێی AI لە جیهاندا پێشکەوتنی زۆری کردووە',
                'content': 'کۆمپانیاکانی تەکنەلۆژیا لە جیهاندا پێشکەوتنی زۆریان لە بواری ژیری دەستکردەوەدا کردووە...',
                'time': '١ کاتژمێر لەمەوپێش',
                'source': 'BBC کوردی',
                'category': 'تەکنەلۆژیا',
                'url': 'https://www.bbc.com/kurdish',
                'image': '/api/news/images/ai-world.jpg',
                'views': 1200,
                'likes': 89
            },
            {
                'id': 5,
                'title': 'کۆنفرانسی کەشووهەوا',
                'description': 'کۆنفرانسی نێودەوڵەتی لەسەر گۆڕانی کەشووهەوا',
                'content': 'لە شاری دوبەیدا کۆنفرانسی نێودەوڵەتی لەسەر گۆڕانی کەشووهەوا بەردەوامە...',
                'time': '٣ کاتژمێر لەمەوپێش',
                'source': 'ڤۆیس ئۆف ئەمریکا',
                'category': 'ژینگە',
                'url': 'https://www.voanews.com/kurdish',
                'image': '/api/news/images/climate-conference.jpg',
                'views': 890,
                'likes': 65
            }
        ]
    }
}

@news_bp.route('/', methods=['GET'])
def get_news():
    """Get news articles by language and category"""
    try:
        language = request.args.get('language', 'ku-sorani')
        category = request.args.get('category', 'kurdistan')
        limit = int(request.args.get('limit', 10))
        
        if language not in NEWS_DATA:
            language = 'ku-sorani'
        
        if category not in NEWS_DATA[language]:
            category = 'kurdistan'
        
        articles = NEWS_DATA[language][category][:limit]
        
        # Add timestamps and randomize some data for realism
        for article in articles:
            article['timestamp'] = datetime.now().isoformat()
            article['language'] = language
            # Add some randomness to views and likes
            article['views'] += random.randint(-50, 100)
            article['likes'] += random.randint(-5, 15)
        
        return jsonify({
            'success': True,
            'language': language,
            'category': category,
            'total': len(articles),
            'articles': articles,
            'sources': NEWS_SOURCES.get(language, [])
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@news_bp.route('/categories', methods=['GET'])
def get_categories():
    """Get available news categories by language"""
    language = request.args.get('language', 'ku-sorani')
    
    if language not in NEWS_DATA:
        language = 'ku-sorani'
    
    categories = list(NEWS_DATA[language].keys())
    
    category_info = {
        'kurdistan': {
            'ku-sorani': 'هەواڵی کوردستان',
            'ku-kurmanji': 'Nûçeyên Kurdistanê',
            'ku-hawrami': 'هەواڵی کوردستان'
        },
        'world': {
            'ku-sorani': 'هەواڵی جیهان',
            'ku-kurmanji': 'Nûçeyên Cîhanê', 
            'ku-hawrami': 'هەواڵی جیهان'
        }
    }
    
    result = []
    for cat in categories:
        result.append({
            'id': cat,
            'name': category_info[cat].get(language, cat),
            'count': len(NEWS_DATA[language][cat]),
            'last_updated': datetime.now().isoformat()
        })
    
    return jsonify({
        'language': language,
        'categories': result,
        'total_sources': len(NEWS_SOURCES.get(language, []))
    })

@news_bp.route('/article/<int:article_id>', methods=['GET'])
def get_article(article_id):
    """Get full article by ID"""
    language = request.args.get('language', 'ku-sorani')
    
    if language not in NEWS_DATA:
        return jsonify({'error': 'Language not supported'}), 400
    
    # Search for article in all categories
    for category, articles in NEWS_DATA[language].items():
        for article in articles:
            if article['id'] == article_id:
                article['language'] = language
                article['category_name'] = category
                article['related_articles'] = get_related_articles(article, language, category)
                return jsonify({
                    'success': True,
                    'article': article
                })
    
    return jsonify({'error': 'Article not found'}), 404

def get_related_articles(current_article, language, category, limit=3):
    """Get related articles based on category and content"""
    related = []
    all_articles = NEWS_DATA[language][category]
    
    for article in all_articles:
        if article['id'] != current_article['id']:
            # Simple similarity based on category
            if article['category'] == current_article['category']:
                related.append({
                    'id': article['id'],
                    'title': article['title'],
                    'time': article['time'],
                    'source': article['source']
                })
    
    return related[:limit]

@news_bp.route('/search', methods=['GET'])
def search_news():
    """Search news articles"""
    try:
        query = request.args.get('q', '').strip()
        language = request.args.get('language', 'ku-sorani')
        limit = int(request.args.get('limit', 10))
        
        if not query:
            return jsonify({'error': 'Search query is required'}), 400
        
        if language not in NEWS_DATA:
            language = 'ku-sorani'
        
        results = []
        
        # Search in all categories for the language
        for category, articles in NEWS_DATA[language].items():
            for article in articles:
                # Simple search in title, description, and content
                if (query.lower() in article['title'].lower() or 
                    query.lower() in article['description'].lower() or
                    query.lower() in article.get('content', '').lower()):
                    article_copy = article.copy()
                    article_copy['language'] = language
                    article_copy['category_name'] = category
                    article_copy['relevance_score'] = calculate_relevance(query, article)
                    results.append(article_copy)
        
        # Sort by relevance and limit results
        results.sort(key=lambda x: x['relevance_score'], reverse=True)
        results = results[:limit]
        
        return jsonify({
            'success': True,
            'query': query,
            'language': language,
            'total': len(results),
            'articles': results
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def calculate_relevance(query, article):
    """Calculate relevance score for search results"""
    score = 0
    query_lower = query.lower()
    
    # Title match (highest weight)
    if query_lower in article['title'].lower():
        score += 10
    
    # Description match
    if query_lower in article['description'].lower():
        score += 5
    
    # Content match
    if query_lower in article.get('content', '').lower():
        score += 3
    
    # Category match
    if query_lower in article['category'].lower():
        score += 2
    
    # Source match
    if query_lower in article['source'].lower():
        score += 1
    
    return score

@news_bp.route('/trending', methods=['GET'])
def get_trending():
    """Get trending news based on views and engagement"""
    language = request.args.get('language', 'ku-sorani')
    limit = int(request.args.get('limit', 5))
    
    if language not in NEWS_DATA:
        language = 'ku-sorani'
    
    # Get all articles and calculate trending score
    trending = []
    for category, articles in NEWS_DATA[language].items():
        for article in articles:
            article_copy = article.copy()
            article_copy['language'] = language
            article_copy['category_name'] = category
            
            # Calculate trending score based on views, likes, and recency
            views_score = article.get('views', 0) * 0.1
            likes_score = article.get('likes', 0) * 2
            time_score = 100  # Recent articles get higher score
            
            article_copy['trending_score'] = views_score + likes_score + time_score
            trending.append(article_copy)
    
    # Sort by trending score and limit
    trending.sort(key=lambda x: x['trending_score'], reverse=True)
    trending = trending[:limit]
    
    return jsonify({
        'success': True,
        'language': language,
        'total': len(trending),
        'articles': trending
    })

@news_bp.route('/sources', methods=['GET'])
def get_sources():
    """Get news sources by language"""
    language = request.args.get('language', 'ku-sorani')
    
    sources = NEWS_SOURCES.get(language, NEWS_SOURCES['ku-sorani'])
    
    # Add statistics for each source
    for source in sources:
        source['article_count'] = random.randint(50, 500)
        source['last_updated'] = datetime.now().isoformat()
        source['reliability_score'] = random.randint(70, 95)
    
    return jsonify({
        'language': language,
        'sources': sources,
        'total': len(sources)
    })

@news_bp.route('/feed', methods=['GET'])
def get_news_feed():
    """Get personalized news feed"""
    language = request.args.get('language', 'ku-sorani')
    categories = request.args.getlist('categories')
    limit = int(request.args.get('limit', 20))
    
    if language not in NEWS_DATA:
        language = 'ku-sorani'
    
    if not categories:
        categories = list(NEWS_DATA[language].keys())
    
    feed = []
    for category in categories:
        if category in NEWS_DATA[language]:
            articles = NEWS_DATA[language][category]
            for article in articles:
                article_copy = article.copy()
                article_copy['language'] = language
                article_copy['category_name'] = category
                feed.append(article_copy)
    
    # Sort by time (most recent first) and limit
    feed.sort(key=lambda x: x.get('views', 0), reverse=True)
    feed = feed[:limit]
    
    return jsonify({
        'success': True,
        'language': language,
        'categories': categories,
        'total': len(feed),
        'articles': feed
    })

@news_bp.route('/images/<filename>')
def serve_news_image(filename):
    """Serve news images"""
    # For demo purposes, return a placeholder
    from flask import send_file
    import io
    
    # Create a simple placeholder image (1x1 pixel)
    placeholder = b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\tpHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\x0cIDATx\x9cc```\x00\x00\x00\x04\x00\x01\xdd\x8d\xb4\x1c\x00\x00\x00\x00IEND\xaeB`\x82'
    
    return send_file(
        io.BytesIO(placeholder),
        mimetype='image/png',
        as_attachment=False,
        download_name=filename
    )

@news_bp.route('/stats', methods=['GET'])
def get_news_stats():
    """Get news statistics"""
    language = request.args.get('language', 'ku-sorani')
    
    if language not in NEWS_DATA:
        language = 'ku-sorani'
    
    stats = {
        'total_articles': 0,
        'by_category': {},
        'by_source': {},
        'total_views': 0,
        'total_likes': 0,
        'last_updated': datetime.now().isoformat()
    }
    
    for category, articles in NEWS_DATA[language].items():
        stats['total_articles'] += len(articles)
        stats['by_category'][category] = len(articles)
        
        for article in articles:
            stats['total_views'] += article.get('views', 0)
            stats['total_likes'] += article.get('likes', 0)
            
            source = article['source']
            if source not in stats['by_source']:
                stats['by_source'][source] = 0
            stats['by_source'][source] += 1
    
    return jsonify({
        'language': language,
        'stats': stats
    })

