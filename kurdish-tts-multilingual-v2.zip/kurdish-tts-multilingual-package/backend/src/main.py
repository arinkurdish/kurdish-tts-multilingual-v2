import os
import sys
# DON'T CHANGE: Add the src directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, render_template, send_from_directory
from flask_cors import CORS

# Import route blueprints
from routes.user import user_bp
from routes.tts import tts_bp
from routes.news import news_bp
from routes.voices import voices_bp

def create_app():
    app = Flask(__name__, 
                static_folder='static',
                static_url_path='')
    
    # Enable CORS for all routes
    CORS(app, origins="*")
    
    # Register blueprints
    app.register_blueprint(user_bp, url_prefix='/api/users')
    app.register_blueprint(tts_bp, url_prefix='/api/tts')
    app.register_blueprint(news_bp, url_prefix='/api/news')
    app.register_blueprint(voices_bp, url_prefix='/api/voices')
    
    # Serve the React app
    @app.route('/')
    def serve_react_app():
        return send_from_directory(app.static_folder, 'index.html')
    
    # Catch all route for React Router
    @app.route('/<path:path>')
    def serve_react_routes(path):
        if path.startswith('api/'):
            # Let API routes handle themselves
            return {'error': 'API endpoint not found'}, 404
        
        # Check if it's a static file
        if '.' in path:
            try:
                return send_from_directory(app.static_folder, path)
            except:
                pass
        
        # Serve React app for all other routes
        return send_from_directory(app.static_folder, 'index.html')
    
    # Health check endpoint
    @app.route('/api/health')
    def health_check():
        return {
            'status': 'healthy',
            'service': 'Kurdish TTS API',
            'version': '2.0.0',
            'features': [
                'Multi-language support (Sorani, Kurmanji, Hawrami)',
                'Custom voice upload',
                'News integration',
                'Multiple audio formats'
            ]
        }
    
    return app

if __name__ == '__main__':
    app = create_app()
    
    # Run the app
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)

