# ڕێنمایی تەواو بۆ پشتگیری سێ زمانی کوردی

## پێناسە

ئەم ڕێنماییە ڕوونکردنەوەی تەواوی سیستەمی سێ زمانە دەکات کە لەم ماڵپەڕەدا بەکارهاتووە. ئەم سیستەمە ڕێگە دەدات بە بەکارهێنەران کە بە ئاسانی لە نێوان سێ زمانی کوردیدا بگۆڕن.

## زمانە پشتگیریکراوەکان

### ١. سۆرانی (ku-sorani)
- **ناوچە:** کوردستانی عێراق، ئێران
- **نووسین:** عەرەبی
- **نموونە:** "سڵاو، چۆنیت؟"
- **تایبەتمەندی:** زمانی فەرمی هەرێمی کوردستان

### ٢. کورمانجی (ku-kurmanji)  
- **ناوچە:** تورکیا، سووریا، ئەرمەنستان
- **نووسین:** لاتینی
- **نموونە:** "Silav, çawa yî?"
- **تایبەتمەندی:** زۆرترین قسەکەری کوردی

### ٣. هەورامی (ku-hawrami)
- **ناوچە:** ئێران، عێراق (هەورامان)
- **نووسین:** عەرەبی
- **نموونە:** "سلام، چطوری؟"
- **تایبەتمەندی:** زمانێکی کۆنی کوردی

## ساختاری تەکنیکی

### Frontend (React)

#### فایلی وەرگێڕان
```javascript
// src/utils/translations.js
export const translations = {
  'ku-sorani': {
    title: 'گۆڕینی نووسینی کوردی بۆ دەنگ',
    subtitle: 'دەقی کوردی بنووسە و بیگۆڕە بۆ دەنگی سروشتی',
    // ...
  },
  'ku-kurmanji': {
    title: 'Veguheztina nivîsa kurdî bo deng',
    subtitle: 'Nivîsa kurdî binivîse û biguherîne bo dengê xwezayî',
    // ...
  },
  'ku-hawrami': {
    title: 'وەرگێڕانی نووسینی کوردی بۆ دەنگ',
    subtitle: 'دەقی کوردی بنووسە و بیگۆڕە بۆ دەنگی سروشتی',
    // ...
  }
};
```

#### کۆمپۆنێنتی هەڵبژاردنی زمان
```javascript
// src/components/LanguageSelector.jsx
const LanguageSelector = ({ currentLanguage, onLanguageChange }) => {
  const languages = [
    { code: 'ku-sorani', name: 'سۆرانی', flag: '🟥🟨🟩' },
    { code: 'ku-kurmanji', name: 'Kurmancî', flag: '🟥🟨🟩' },
    { code: 'ku-hawrami', name: 'هەورامی', flag: '🟥🟨🟩' }
  ];
  // ...
};
```

### Backend (Flask)

#### API Endpoints بۆ هەر زمان
```python
# src/routes/tts.py
@tts_bp.route('/convert', methods=['POST'])
def convert_text_to_speech():
    data = request.get_json()
    text = data.get('text', '')
    language = data.get('language', 'ku-sorani')
    voice_type = data.get('voice_type', 'news')
    
    # TTS processing based on language
    if language == 'ku-sorani':
        # Sorani TTS processing
    elif language == 'ku-kurmanji':
        # Kurmanji TTS processing  
    elif language == 'ku-hawrami':
        # Hawrami TTS processing
```

#### هەواڵ بۆ هەر زمان
```python
# src/routes/news.py
@news_bp.route('/', methods=['GET'])
def get_news():
    language = request.args.get('language', 'ku-sorani')
    category = request.args.get('category', 'all')
    
    if language == 'ku-sorani':
        return get_sorani_news(category)
    elif language == 'ku-kurmanji':
        return get_kurmanji_news(category)
    elif language == 'ku-hawrami':
        return get_hawrami_news(category)
```

## دەنگە تایبەتەکان بۆ هەر زمان

### ساختاری فۆڵدەر
```
voices/
├── sorani/
│   ├── news/
│   ├── storyteller/
│   ├── singer/
│   └── custom/
├── kurmanji/
│   ├── news/
│   ├── storyteller/
│   ├── singer/
│   └── custom/
└── hawrami/
    ├── news/
    ├── storyteller/
    ├── singer/
    └── custom/
```

### زیادکردنی دەنگی تایبەت

#### ١. ئامادەکردنی داتا
```
my_voice_sorani/
├── audio/
│   ├── sentence_001.wav
│   ├── sentence_002.wav
│   └── ...
├── transcript.txt
└── config.json
```

#### ٢. فایلی transcript.txt
```
sentence_001.wav|سڵاو، ناوم [ناوت]ە و من قسەکەری سۆرانیم
sentence_002.wav|ئەم دەنگە بۆ ڕاهێنانی مۆدێلی TTS بەکاردێت
sentence_003.wav|هیوادارم ئەم تەکنەلۆژیایە سوودی بۆ کوردان هەبێت
```

#### ٣. فایلی config.json
```json
{
  "voice_name": "دەنگی من - سۆرانی",
  "language": "ku-sorani",
  "speaker_id": "my_voice_sorani",
  "gender": "male",
  "age": "adult",
  "description": "دەنگێکی گونجاو بۆ خوێندنەوەی هەواڵ و چیرۆک",
  "sample_rate": 22050,
  "total_duration": 1800,
  "total_sentences": 150
}
```

## سەرچاوەی هەواڵ بۆ هەر زمان

### سۆرانی
- کوردستان ٢٤
- رووداو
- کوردپرێس
- هەواڵی کوردستان
- NRT

### کورمانجی
- ANF News
- Rojava News
- Hawar News
- Mezopotamya Agency

### هەورامی
- سەرچاوەی نەریتی هەورامان
- کۆمەڵگای هەورامی
- میدیای ناوچەیی

## چۆن زمانێکی نوێ زیاد بکەین

### ١. زیادکردن بۆ Frontend

#### وەرگێڕان زیاد بکە
```javascript
// src/utils/translations.js
export const translations = {
  // existing languages...
  'ku-zazaki': {
    title: 'Çarnayışê nuşteyê kurdki ser veng',
    subtitle: 'Nuşteyê kurdki binuse û biguherîne vengê xwezayî',
    // ...
  }
};
```

#### زمان زیاد بکە بۆ selector
```javascript
// src/components/LanguageSelector.jsx
const languages = [
  // existing languages...
  { code: 'ku-zazaki', name: 'Zazakî', flag: '🟥🟨🟩' }
];
```

### ٢. زیادکردن بۆ Backend

#### TTS support زیاد بکە
```python
# src/routes/tts.py
elif language == 'ku-zazaki':
    # Zazaki TTS processing
    audio_url = process_zazaki_tts(text, voice_type)
```

#### هەواڵ زیاد بکە
```python
# src/routes/news.py
elif language == 'ku-zazaki':
    return get_zazaki_news(category)
```

### ٣. دەنگەکان ئامادە بکە
```
voices/zazaki/
├── news/
├── storyteller/
├── singer/
└── custom/
```

## بەکارهێنانی API

### گۆڕینی زمان
```javascript
// Frontend
const changeLanguage = (newLanguage) => {
  setCurrentLanguage(newLanguage);
  localStorage.setItem('preferred_language', newLanguage);
  // Update all content
};
```

### ناردنی داواکاری TTS
```javascript
const convertToSpeech = async (text, language, voiceType) => {
  const response = await fetch('/api/tts/convert', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      text: text,
      language: language,
      voice_type: voiceType
    })
  });
  return response.json();
};
```

### وەرگرتنی هەواڵ
```javascript
const getNews = async (language, category = 'all') => {
  const response = await fetch(`/api/news/?language=${language}&category=${category}`);
  return response.json();
};
```

## چاکسازی و گەشەپێدان

### زیادکردنی وەرگێڕانی نوێ
1. فایلی `translations.js` بکەرەوە
2. وەرگێڕانی نوێ زیاد بکە
3. کۆمپۆنێنتەکان نوێ بکەرەوە

### باشترکردنی TTS
1. مۆدێلی نوێ ڕابهێنە
2. دەنگە نوێ زیاد بکە
3. کوالیتی دەنگ باشتر بکە

### زیادکردنی سەرچاوەی هەواڵ
1. API ی نوێ تێکەڵ بکە
2. Parser ی نوێ بنووسە
3. کاتی نوێکردنەوە ڕێک بخە

## کێشە باوەکان و چارەسەر

### کێشەی وەرگێڕان
- **کێشە:** وەرگێڕان نیشان نادرێت
- **چارەسەر:** بڕوانە بە console بۆ هەڵەکان، دڵنیابە کە key ی وەرگێڕان ڕاستە

### کێشەی TTS
- **کێشە:** دەنگ دروست نابێت
- **چارەسەر:** بڕوانە بە backend logs، دڵنیابە کە API کاردەکات

### کێشەی هەواڵ
- **کێشە:** هەواڵ بار نابێت
- **چارەسەر:** بڕوانە بە network requests، دڵنیابە کە سەرچاوەکان بەردەستن

## ئامۆژگارییەکان

### بۆ گەشەپێدەران
- هەمیشە fallback language (سۆرانی) بەکار بهێنە
- وەرگێڕانەکان لە فایلی جیا هەڵبگرە
- کاشی وەرگێڕان بەکار بهێنە بۆ خێراکردن

### بۆ بەکارهێنەران
- زمانی دڵخوازت هەڵبژێرە لە یەکەم جار
- دەنگی گونجاو هەڵبژێرە بۆ مەبەستەکەت
- فایلی دەنگ لە فۆرماتی گونجاودا دابەزێنە

---

**ئەم ڕێنماییە بەردەوام نوێ دەکرێتەوە بە زیادبوونی تایبەتمەندی نوێ**

